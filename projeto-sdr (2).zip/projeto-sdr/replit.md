# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: Firebase Firestore (via firebase-admin)
- **AI**: Google Gemini (via @google/genai) — transcription + analysis of HubSpot calls
- **CRM**: HubSpot API (via axios)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   └── api-server/         # Express API server
│       └── src/
│           ├── config.ts           # All env vars / CONFIG object
│           ├── firebase.ts         # Firebase Admin init + db export
│           ├── clients.ts          # HubSpot axios client + Gemini client
│           ├── utils.ts            # Helper functions
│           ├── services/
│           │   ├── hubspot.ts      # fetchCall, fetchOwnerDetails, searchCallsInHubSpot
│           │   ├── ai.ts           # transcribeRecordingFromHubSpot, analyzeCall
│           │   └── processCall.ts  # Main business logic
│           ├── routes/
│           │   ├── health.ts       # GET /api/healthz
│           │   ├── calls.ts        # /api/calls, /api/analyze-call, /api/hubspot-webhook, /api/analyze-calls-search
│           │   └── index.ts        # Router barrel
│           ├── app.ts              # Express app setup
│           └── index.ts            # Entry point (reads PORT, starts server)
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection (PostgreSQL)
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## API Routes

All routes are mounted under `/api`:

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/healthz` | Health check |
| GET | `/api/calls` | List last 30 analyzed calls (DONE status) |
| POST | `/api/analyze-call` | Process a single call by `callId` |
| POST | `/api/hubspot-webhook` | HubSpot webhook trigger |
| POST | `/api/analyze-calls-search` | Batch process recent calls from HubSpot |

## Business Logic (processCall)

1. Fetch call metadata from HubSpot
2. Skip if call is too short (`MIN_DURATION_MS`)
3. Retry fetching recording URL if not yet available
4. Skip if no recording URL after retries
5. Transcribe audio via Gemini AI
6. Skip if transcript is too short (`MIN_TEXT_LENGTH_FOR_ANALYSIS`)
7. Analyze call quality with Gemini (SPIN Selling methodology)
8. Save result to Firestore

## Required Environment Variables

Set these as secrets in Replit:

| Variable | Required | Description |
|----------|----------|-------------|
| `HUBSPOT_TOKEN` | ✅ | HubSpot Private App token |
| `GEMINI_API_KEY` | ✅ | Google Gemini API key |
| `FIREBASE_SERVICE_ACCOUNT_JSON` | ✅ | Full JSON of Firebase service account |
| `GEMINI_ANALYSIS_MODEL` | optional | Default: `gemini-2.0-flash` |
| `GEMINI_TRANSCRIPTION_MODEL` | optional | Default: `gemini-2.0-flash` |
| `CALLS_COLLECTION` | optional | Firestore collection name. Default: `calls_analysis` |
| `MIN_DURATION_MS` | optional | Min call duration in ms. Default: `120000` (2 min) |
| `MIN_TEXT_LENGTH_FOR_ANALYSIS` | optional | Min transcript length. Default: `180` |

## TypeScript & Composite Projects

Every lib package extends `tsconfig.base.json` with `composite: true`. Artifact packages are leaf nodes — checked with `tsc --noEmit` only.

- `pnpm run typecheck` — full check (libs + artifacts)
- `pnpm run build` — typecheck then build all

## Packages

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server. See routes table above.

- `pnpm --filter @workspace/api-server run dev` — dev server
- `pnpm --filter @workspace/api-server run build` — production bundle (`dist/index.cjs`)

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI 3.1 spec + Orval codegen config.

Run codegen: `pnpm --filter @workspace/api-spec run codegen`
